import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.MinPQ;
import edu.princeton.cs.algs4.Queue;
import edu.princeton.cs.algs4.Stopwatch;
import edu.princeton.cs.algs4.StdOut;

import java.util.Comparator;

public class Solver {
    private final Queue<Board> solution;
    private boolean isSolvable;

    public Solver(Board initial) {
        if (initial == null) {
            throw new IllegalArgumentException();
        }

        InnerSolver solverOrigin = new InnerSolver(initial);
        InnerSolver solverTwin = new InnerSolver(initial.twin());

        while (true) {
            if (solverOrigin.isSolvable) {
                isSolvable = true;
                solution = solverOrigin.solution;
                break;
            } else if (solverTwin.isSolvable) {
                isSolvable = false;
                solution = new Queue<>();
                break;
            }

            solverOrigin.nextStep();
            solverTwin.nextStep();
        }
    }

    private static class InnerSolver {

        private final MinPQ<Board> pq;
        private final Queue<Board> solution = new Queue<>();
        private boolean isSolvable;

        public InnerSolver(Board initial) {
            pq = new MinPQ<>(initial.dimension(), new BoardComparator());
            pq.insert(initial);

            if (initial.isGoal()) {
                isSolvable = true;
            }
        }

        public void nextStep() {
            Board out = pq.delMin();
            solution.enqueue(out);

            for (Board neighbor : out.neighbors()) {
                if (isInSolution(neighbor)) {
                    continue;
                }

                if (neighbor.isGoal()) {
                    isSolvable = true;
                    break;
                }

                pq.insert(neighbor);
            }
        }

        private boolean isInSolution(Board board) {
            for (Board solutionBoard : solution) {
                if (board.equals(solutionBoard)) {
                    return true;
                }
            }
            return false;
        }
    }

    // is the initial board solvable? (see below)

    public boolean isSolvable() {
        return isSolvable;
    }
    // min number of moves to solve initial board

    public int moves() {
        return solution.size();
    }
    // sequence of boards in a shortest solution

    public Iterable<Board> solution() {
        return solution;
    }

    public static void main(String[] args) {

//        args = new String[] { "puzzle08.txt" };

        if (args == null || args.length == 0) {

            if (args == null) {
                Stopwatch w = new Stopwatch();
                solve("puzzle4x4-unsolvable.txt", true);
                StdOut.println("TIME: " + w.elapsedTime());
            } else {
                for (int i = 0; i <= 50; i++) {
                    Stopwatch w = new Stopwatch();
                    String fileName = "puzzle" + String.format("%2d", i).replace(' ', '0') + ".txt";
                    solve(fileName, false);
//                    solve("puzzle4x4-" + String.format("%2d", i).replace(' ', '0') + ".txt");
                    if (w.elapsedTime() > 0.1) {
                        StdOut.println("#" + i + " TIME: " + w.elapsedTime());
                    }
                }
            }
        } else {
            solve(args[0], true);
        }
    }

    private static void solve(String fileName, boolean printInitial) {
        In in = new In(fileName);
        int n = in.readInt();
        int[][] tiles = new int[n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                tiles[i][j] = in.readInt();
            }
        }

        Board initial = new Board(tiles);

        if (printInitial) {
            StdOut.println("Initial: " + initial);
        }

        Solver solver = new Solver(initial);

        if (!solver.isSolvable())
            StdOut.println(fileName + " No solution possible");
        else {
            StdOut.println(fileName + " number of moves = " + solver.moves());
            for (Board board : solver.solution()) {
                StdOut.println(board);
            }
        }
    }

    private static class BoardComparator implements Comparator<Board> {

        @Override
        public int compare(Board o1, Board o2) {
            return Integer.compare(o1.manhattan(), o2.manhattan());
        }
    }
}
